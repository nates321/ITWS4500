Nathan Strelser Lab 1

Twitter Ticker


W3C
twitter api references
bootstrap grid references

talked to corey and my team to figure out basic ideas of how to do it
