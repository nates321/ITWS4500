Nathan Strelser



https://github.com/nates321/ITWS4500 - my github repo

pictures included:

picture of local github
picture of mantisbt config


group repo github:

https://github.com/mwang25277/ShowOfHands
server: http://159.203.84.202:3000/
	Username: corey
	Password: pass


https://github.com/mwang25277/ShowOfHands/issues


project description:

The project will be a web application that provides analytics on United States federal legislative data,
 with a main focus on congressional voting data. The web application will include data visualizations on
 a variety of different interesting metrics. For example, one such metric could be how much a particular
 congressman voted in/out of his/her party. Essentially, the application will give users an easy way to
 understand and interpret the data that is analyzed.