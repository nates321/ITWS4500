NAthan STrelser
661476303
streln

resources used:

stack overflow 
twitter node package
twitter api resource

mongodb website and node package rescources


I made it so when you type npm install, it creates the database if it isnt there already. then type npm start to start tje server

fixed formatting when going to smaller screen, now correctly displays hashtags under the heading

when its displaying tweets, if it reaches the end of the tweets, it loops back to the beggining. at the top theres an option to search again
