Name:
Nathan Strelser

resources:
W3SCHOOLS
OPENWEATHERMAP API DOCUMENTATION
Google maps embeded api documebtation
my old work

i used the same style as i did for the tweets pretty much exceptdidnt put any delay
in seeing the 5 days forecast on the side.

I had a bunch of blank space on the bottom left when the screen was at full size so i 
decided to put the goodle maps embedded api into my work, but resizing the map as the window changed sizes was
harder than i expected. so i commented out the code for the google maps api in index.html and script.js. uncomment
it to see what it looks like so far in my code. i commented it out so the site looks better with its working version