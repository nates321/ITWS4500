NAthan STrelser
661476303
streln

resources used:

stack overflow 
twitter node package
twitter api resource

mongodb website and node package rescources


i used the same file from my lab6 and just added new form inputs

At first i was super confused what i was supposed to do. but they way i interperetted it was:

query twitter query's twitter node package and displays output

query database query's the data base and displays output

build db query's the twitter node package and uploads it to the database

export query's the database and exports as a certain filename


I found it really hard to use mongo to find and insert collections at first, but then it got easier. the hardest part was getting the data and making sure it was in the right json format.

all the console logs were to help me to debug what was happening and where in the program it went at different times before i figured out to use the callback method

