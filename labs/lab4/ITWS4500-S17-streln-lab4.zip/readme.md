Name: nathan strelser

resources: 
w3schools
cssmedaiqueries.com
stackoverflow

i talked to corey burns about how to call the api's using angular



as in lab 2, i couldnt figure out resizing the map, but it looks a little better so i kept it uncommented. 

I feel like i couldve used angular more for this lab, but it accomplishes the same thing this way and i feel as if i used it a sufficient ammount. i started from the demo that you had in class and changed it up to use api's

for ajax i used getJSON which is just a shorter way of $.AJAX then doing GET

i used media queries to change how the site looked in portrait and landscape. since most phones are portrait

