NAthan STrelser
661476303
streln

resources used:

stack overflow 
twitter node package
twitter api resource
angular chart js and  chart js documentation


this lab was pretty straight forward, choosing what to visualize was the hardest part.
i made it take it from the api client so it analyzes the most recent tweets, not whatever is in the database