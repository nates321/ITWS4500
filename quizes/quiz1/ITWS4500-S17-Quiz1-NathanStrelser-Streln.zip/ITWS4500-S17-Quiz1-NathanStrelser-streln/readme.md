NAthan STrelser
661476303
streln

didnt know if we needed a readme so here's one.
I used google a lot, especially for request and body parser for the node js part.

I tried implementing a way to catch invalid zip codes but didnt finish